#!/usr/bin/env bash

rm -rf tmp
rm -rf build
rm -rf src
rm -rf toolchains
