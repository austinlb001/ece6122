// AUTHOR: AUSTIN LOGAN BARBER
// FILE NAME: Lab0_Problem1.cpp
// DATE CREATED: 2025 AUGUST 20
// DATE LAST UPDATED: 2025 AUGUST 20
// CLASS: ECE 6122 - Q
// PURPOSE: This file is my solution to ECE 6122 >> LAB 0 >> PROBLEM 1.

/******************************* I N C L U D E ********************************/
#include<iostream>

/******************************************************************************/
/******************************************************************************/


/******************************** U S E *********************************/
using namespace std;

/******************************************************************************/
/******************************************************************************/


/********************************** M A I N ***********************************/
int main()
{
    cout << "My name is: Austin Barber" << endl;
    cout << "This (\") is a double quote." << endl;
    cout << "This (\') is a single quote." << endl;
    cout << "This (\\) is a backslash." << endl;
    cout << "This (/) is a forward slash." << endl;

    // Return zero for clean exit
    return 0;
}

/******************************************************************************/
/******************************************************************************/
